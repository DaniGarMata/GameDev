<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Tileset" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="72" columns="8">
 <image source="Tileset.png" width="274" height="308"/>
</tileset>
