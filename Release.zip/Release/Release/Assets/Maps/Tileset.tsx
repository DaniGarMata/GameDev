<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="Tileset" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="72" columns="8">
 <image source="Tileset.png" width="274" height="308"/>
 <terraintypes>
  <terrain name="Grass" tile="14"/>
  <terrain name="Clouds" tile="57"/>
  <terrain name="Hills" tile="11"/>
  <terrain name="Semisolid" tile="19"/>
 </terraintypes>
 <tile id="5" terrain=",,,0"/>
 <tile id="6" terrain=",,0,0"/>
 <tile id="7" terrain=",,0,"/>
 <tile id="10" terrain=",2,,2"/>
 <tile id="11" terrain="2,2,2,2"/>
 <tile id="12" terrain="2,,2,"/>
 <tile id="13" terrain=",0,,0"/>
 <tile id="14" terrain="0,0,0,0"/>
 <tile id="15" terrain="0,,0,"/>
 <tile id="18" terrain=",,,3"/>
 <tile id="19" terrain=",,3,3"/>
 <tile id="20" terrain=",,3,"/>
 <tile id="26" terrain=",3,,3"/>
 <tile id="27" terrain="3,3,3,3"/>
 <tile id="28" terrain="3,,3,"/>
 <tile id="56" terrain=",,,1"/>
 <tile id="57" terrain=",,1,1"/>
 <tile id="58" terrain=",,1,"/>
 <tile id="59" terrain=",1,,"/>
 <tile id="60" terrain="1,1,,"/>
 <tile id="61" terrain="1,,,"/>
 <tile id="64" terrain=",1,,1"/>
 <tile id="65" terrain="1,1,1,1"/>
 <tile id="66" terrain="1,,1,"/>
 <tile id="67" terrain=",,,2"/>
 <tile id="68" terrain=",,2,2"/>
 <tile id="69" terrain=",,2,"/>
</tileset>
